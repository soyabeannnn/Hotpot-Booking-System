<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
    <body>
        <footer>
        <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ"><i class="fa-brands fa-facebook" style="color: #ffffff;"></i></a>

        <a href="https://www.instagram.com/p/CtqOw2Mp5Ac/"><i class="fa-brands fa-instagram" style="color: #ffffff;"></i></a>

        <a href="https://www.youtube.com/watch?v=FqZYHHNntk0"><i class="fa-brands fa-twitter" style="color: #ffffff;"></i></a>
                                          
        <p><span>Hotto © copyright</span></p>
</footer>
</body>
</html>

<style>
    body{
        margin: 0;
        padding: 0;
    }

    i{
        font-size: 30px;
        width:35px;
    }
    footer{
        justify-content: center;
        align-items: center;
        width:100%;
        padding-top: 50px;
        padding-bottom:50px;
        background-color:#333333;
        color: white;
        text-align: center;
        font-size: 18px;
    }

    
    footer a{
        text-decoration: none;
    }

    p span{
        display: inline;
    }

</style>
